﻿package com.scheduler.factories;

import com.scheduler.models.Task;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;

public class TaskFactory {
    private static final Logger logger = LogManager.getLogger(TaskFactory.class);

    public static Task createTask(String description, String startTimeStr, String endTimeStr, String priority) {
        if (description == null || description.trim().isEmpty()) {
            System.out.println("Error: Description cannot be empty.");
            logger.warn("Empty description provided to TaskFactory");
            return null;
        }
        if (priority == null || priority.trim().isEmpty()) {
            System.out.println("Error: Priority cannot be empty. Use High, Medium, or Low.");
            logger.warn("Empty priority provided to TaskFactory");
            return null;
        }
        if (!isValidPriority(priority)) {
            System.out.println("Error: Invalid priority. Allowed values: High, Medium, Low.");
            logger.warn("Invalid priority provided to TaskFactory");
            return null;
        }

        try {
            LocalTime start = LocalTime.parse(startTimeStr);
            LocalTime end = LocalTime.parse(endTimeStr);
            if (!end.isAfter(start)) {
                System.out.println("Error: End time must be after start time.");
                logger.warn("End time is not after start time");
                return null;
            }
            return new Task(description.trim(), start, end, capitalize(priority.trim()));
        } catch (DateTimeParseException e) {
            System.out.println("Error: Invalid time format. Please use HH:mm (e.g., 09:00).");
            logger.error("Time parse error: {}", e.getMessage());
            return null;
        } catch (Exception e) {
            System.out.println("Error: Failed to create task. " + e.getMessage());
            logger.error("Unexpected error in TaskFactory", e);
            return null;
        }
    }

    private static boolean isValidPriority(String p) {
        String v = p.trim().toLowerCase();
        return v.equals("high") || v.equals("medium") || v.equals("low");
    }

    private static String capitalize(String s) {
        if (s.isEmpty()) return s;
        String lower = s.toLowerCase();
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }
}
