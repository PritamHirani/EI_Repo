﻿package com.scheduler.models;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Task implements Comparable<Task> {
    private final String description;
    private final LocalTime startTime;
    private final LocalTime endTime;
    private final String priority;

    public Task(String description, LocalTime startTime, LocalTime endTime, String priority) {
        this.description = description;
        this.startTime = startTime;
        this.endTime = endTime;
        this.priority = priority;
    }

    public String getDescription() { return description; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public String getPriority() { return priority; }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");
        return String.format("%s-%s: %s [%s]",
                startTime.format(fmt),
                endTime.format(fmt),
                description,
                priority);
    }

    @Override
    public int compareTo(Task other) {
        return this.startTime.compareTo(other.startTime);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return Objects.equals(description, task.description) &&
               Objects.equals(startTime, task.startTime) &&
               Objects.equals(endTime, task.endTime) &&
               Objects.equals(priority, task.priority);
    }

    @Override
    public int hashCode() {
        return Objects.hash(description, startTime, endTime, priority);
    }
}
