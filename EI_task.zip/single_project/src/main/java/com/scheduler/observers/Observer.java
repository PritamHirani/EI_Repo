﻿package com.scheduler.observers;

public interface Observer {
    void update(String message);
}
