﻿package com.scheduler.observers;

public class ConflictNotifier implements Observer {
    @Override
    public void update(String message) {
        System.out.println("CONFLICT NOTIFICATION: " + message);
    }
}
