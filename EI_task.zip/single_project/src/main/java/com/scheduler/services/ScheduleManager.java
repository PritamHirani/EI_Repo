﻿package com.scheduler.services;

import com.scheduler.models.Task;
import com.scheduler.observers.Observer;
import com.scheduler.observers.Subject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScheduleManager implements Subject {
    private static final Logger logger = LogManager.getLogger(ScheduleManager.class);
    private static ScheduleManager instance;
    private final List<Task> tasks;
    private final List<Observer> observers;

    private ScheduleManager() {
        tasks = new ArrayList<>();
        observers = new ArrayList<>();
    }

    public static synchronized ScheduleManager getInstance() {
        if (instance == null) {
            instance = new ScheduleManager();
            logger.info("ScheduleManager instance created");
        }
        return instance;
    }

    public synchronized boolean addTask(Task newTask) {
        if (newTask == null) {
            logger.warn("addTask called with null");
            return false;
        }

        for (Task existing : tasks) {
            if (hasTimeConflict(newTask, existing)) {
                String msg = String.format("Cannot add '%s' (%s-%s) because it conflicts with existing task '%s' (%s-%s).",
                        newTask.getDescription(),
                        newTask.getStartTime(), newTask.getEndTime(),
                        existing.getDescription(),
                        existing.getStartTime(), existing.getEndTime());
                notifyObservers(msg);
                logger.warn("Time conflict: {}", msg);
                return false;
            }
        }

        tasks.add(newTask);
        logger.info("Task added: {}", newTask.getDescription());
        System.out.println("Task added: " + newTask);
        return true;
    }

    private boolean hasTimeConflict(Task a, Task b) {
        return a.getStartTime().isBefore(b.getEndTime()) && a.getEndTime().isAfter(b.getStartTime());
    }

    public synchronized boolean removeTask(String description) {
        if (description == null || description.trim().isEmpty()) {
            logger.warn("removeTask called with empty description");
            return false;
        }
        String desc = description.trim();
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).getDescription().equalsIgnoreCase(desc)) {
                Task removed = tasks.remove(i);
                logger.info("Removed task: {}", removed.getDescription());
                System.out.println("Removed task: " + removed);
                return true;
            }
        }
        logger.info("Task not found for removal: {}", desc);
        return false;
    }

    public synchronized List<Task> getTasks() {
        List<Task> copy = new ArrayList<>(tasks);
        Collections.sort(copy);
        return copy;
    }

    @Override
    public synchronized void addObserver(Observer o) {
        if (o != null && !observers.contains(o)) observers.add(o);
    }

    @Override
    public synchronized void removeObserver(Observer o) {
        observers.remove(o);
    }

    @Override
    public synchronized void notifyObservers(String message) {
        for (Observer o : new ArrayList<>(observers)) {
            try {
                o.update(message);
            } catch (Exception e) {
                logger.error("Observer update failed", e);
            }
        }
    }
}
