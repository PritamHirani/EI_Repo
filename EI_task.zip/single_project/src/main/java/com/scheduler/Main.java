﻿package com.scheduler;

import com.scheduler.factories.TaskFactory;
import com.scheduler.models.Task;
import com.scheduler.observers.ConflictNotifier;
import com.scheduler.services.ScheduleManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Scanner;

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);
    private static final Scanner scanner = new Scanner(System.in);
    private static final ScheduleManager manager = ScheduleManager.getInstance();

    public static void main(String[] args) {
        logger.info("Astronaut Daily Schedule Organizer starting");
        manager.addObserver(new ConflictNotifier());

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt();
            switch (choice) {
                case 1: handleAddTask(); break;
                case 2: handleRemoveTask(); break;
                case 3: handleViewTasks(); break;
                case 4:
                    running = false;
                    System.out.println("Exiting. Goodbye.");
                    break;
                default:
                    System.out.println("Invalid choice. Enter 1-4.");
            }
        }

        scanner.close();
        logger.info("Application stopped");
    }

    private static void printMenu() {
        System.out.println("\n=== Astronaut Daily Schedule Organizer ===");
        System.out.println("1. Add Task");
        System.out.println("2. Remove Task");
        System.out.println("3. View Tasks");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");
    }

    private static int readInt() {
        String line = scanner.nextLine();
        try {
            return Integer.parseInt(line.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    private static void handleAddTask() {
        System.out.print("Description: ");
        String desc = scanner.nextLine();

        System.out.print("Start time (HH:mm): ");
        String start = scanner.nextLine();

        System.out.print("End time (HH:mm): ");
        String end = scanner.nextLine();

        System.out.print("Priority (High/Medium/Low): ");
        String prio = scanner.nextLine();

        Task t = TaskFactory.createTask(desc, start, end, prio);
        if (t != null) {
            boolean ok = manager.addTask(t);
            if (!ok) {
                System.out.println("Task not added due to conflict or error.");
            }
        }
    }

    private static void handleRemoveTask() {
        System.out.print("Enter description of task to remove: ");
        String desc = scanner.nextLine();
        boolean removed = manager.removeTask(desc);
        if (!removed) {
            System.out.println("Task not found: " + desc);
        }
    }

    private static void handleViewTasks() {
        System.out.println("\nCurrent tasks:");
        var list = manager.getTasks();
        if (list.isEmpty()) {
            System.out.println("No tasks scheduled.");
            return;
        }
        list.forEach(System.out::println);
    }
}
